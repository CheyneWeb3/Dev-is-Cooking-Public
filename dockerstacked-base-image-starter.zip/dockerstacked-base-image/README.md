# DockerStacked Base Image Starter

This pack is the proposed first cut for turning the proven DND DockerStacked server layer into a reusable project bootstrap image.

The goal is one Docker image that can be run from Docker Compose on a fresh controller host to:

1. install/verify Docker access,
2. clone or mount a DockerStacked project repo,
3. accept either an existing `env.gpg` or a plain `.env`,
4. encrypt the `.env` into `env.gpg` when needed,
5. place secrets in the expected upload/runtime location,
6. start the controller stack,
7. leave the server ready for WireGuard joins, Cloudflare routes, Dockhand, and Mode B recovery.

This is a starter scaffold. Before using on production, merge it into the main repo and test it on a throwaway Linode.

## Files

```txt
Dockerfile
entrypoint.sh
docker-compose.init.yml
project.env.example
scripts/encrypt-env.sh
scripts/init-controller.sh
docs/DOCKERSTACKED_BASE_TEMPLATE_PLAN.md
docs/OPERATOR_FLOW.md
docs/SECRET_HANDLING.md
docs/REPO_MERGE_NOTES.md
```

## Target image name

```txt
ghcr.io/<org>/dockerstacked-init:latest
```

## Fast start with existing env.gpg

```bash
cp project.env.example project.env
# edit project.env

mkdir -p input output controller-data
cp /path/to/env.gpg input/env.gpg

docker compose --env-file project.env -f docker-compose.init.yml run --rm dockerstacked-init init-controller
```

## Fast start from plain .env

```bash
cp project.env.example project.env
# edit project.env and set DND_ENV_ENCRYPTION_MODE=symmetric or recipient

mkdir -p input output controller-data
cp /path/to/.env input/.env

docker compose --env-file project.env -f docker-compose.init.yml run --rm dockerstacked-init encrypt-env

docker compose --env-file project.env -f docker-compose.init.yml run --rm dockerstacked-init init-controller
```

## Important

Do not bake secrets into the image. Secrets should come from mounted files, Docker secrets, or host-only env files.
