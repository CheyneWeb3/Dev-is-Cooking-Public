# DockerStacked Base Template Plan

## Purpose

Turn the proven DockerStacked server layer into a reusable base platform for future projects.

The target outcome is a Docker image that can be launched with Docker Compose on a fresh controller server and given either:

- an existing `env.gpg`, or
- a plain `.env` that the bootstrap image encrypts into `env.gpg`.

After this first bootstrap, the controller should be ready to run the normal DockerStacked flow:

- controller menu,
- WireGuard internal mesh,
- join package server,
- Cloudflare tunnel route,
- shared Redis,
- Dockhand private UI,
- Hawser edge tokens,
- Mode B recovery snapshots.

## Layer split

### Reusable platform layer

These should stay generic:

- controller bootstrap image,
- WireGuard controller setup,
- join-code issue/serve flow,
- joined-node WireGuard install,
- dndops SSH proof,
- shared Redis over WireGuard,
- controller menu,
- push update flow,
- Dockhand private UI,
- Hawser edge launcher,
- Mode B backup/restore runner.

### Project application layer

These change per project:

- backend API code,
- frontend code,
- Docker compose service names,
- public domain names,
- Cloudflare tunnel token/routes,
- managed MongoDB URI,
- OAuth/Telegram/etc app credentials,
- branding/assets,
- GitHub repo/branch.

## Image roles

The first image should be named conceptually:

```txt
dockerstacked-init
```

It should not run forever. It is a bootstrap/admin image.

It should support commands:

```txt
preflight
encrypt-env
init-controller
print-summary
```

A later image can become a long-running controller appliance, but do not combine that with the first version. Keep the initial image boring and controlled.

## Security rule

No private keys, tokens, `.env`, or `env.gpg` contents are baked into the image.

Secrets enter only through mounted files or Docker secrets.
