# Operator Flow

## Fresh controller with existing env.gpg

```bash
mkdir -p dockerstacked-init/input dockerstacked-init/output dockerstacked-init/controller-data
cd dockerstacked-init
cp project.env.example project.env
cp /secure/location/env.gpg input/env.gpg

docker compose --env-file project.env -f docker-compose.init.yml run --rm dockerstacked-init preflight
docker compose --env-file project.env -f docker-compose.init.yml run --rm dockerstacked-init init-controller
```

## Fresh controller from plain .env

```bash
mkdir -p dockerstacked-init/input dockerstacked-init/output dockerstacked-init/controller-data
cd dockerstacked-init
cp project.env.example project.env
cp /secure/location/.env input/.env
```

Edit `project.env`:

```txt
DND_ENV_ENCRYPTION_MODE=symmetric
ENV_GPG_PASSPHRASE=temporary-strong-passphrase
```

Then:

```bash
docker compose --env-file project.env -f docker-compose.init.yml run --rm dockerstacked-init encrypt-env
docker compose --env-file project.env -f docker-compose.init.yml run --rm dockerstacked-init init-controller
```

## After controller init

Use the normal controller menu:

```bash
cd /opt/DND-Cooking-main
./ops/docker-wg-lab/dnd-controller-menu.sh
```

For future generic projects, the path should become:

```bash
/opt/<project-name>-main
```

## First validation

```bash
wg show dndwg0
curl -fsS http://10.77.0.1:18300 >/dev/null && echo dockhand-ok
```

After joining a server:

```bash
bash ./ops/docker-wg-lab/dnd-controller-wireguard-ssh-check.sh
curl -fsS https://<public-api-host>/health
```

Then take a Mode B backup.
