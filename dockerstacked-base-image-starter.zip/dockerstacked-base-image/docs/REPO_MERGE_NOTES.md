# Repo Merge Notes

Suggested repo location:

```txt
ops/bootstrap-image/
```

Suggested files:

```txt
ops/bootstrap-image/Dockerfile
ops/bootstrap-image/entrypoint.sh
ops/bootstrap-image/docker-compose.init.yml
ops/bootstrap-image/project.env.example
ops/bootstrap-image/scripts/encrypt-env.sh
ops/bootstrap-image/scripts/init-controller.sh
docs/dockerstacked-base-template-plan.md
```

## Required testing before production

1. Build image locally.
2. Run `preflight` on a throwaway controller host.
3. Run `encrypt-env` using a fake `.env`.
4. Run `init-controller` in dry-run mode.
5. Run `init-controller` with `DND_BOOTSTRAP_EXECUTE=1` on throwaway host.
6. Confirm controller starts.
7. Join one disposable server.
8. Confirm WG, SSH proof, public health, Dockhand.
9. Take and restore Mode B backup.

## Open design decision

Whether the base image should clone the application repo directly or unpack a release artifact.

Recommended first version: clone repo.
Recommended later version: support either clone or release artifact.
