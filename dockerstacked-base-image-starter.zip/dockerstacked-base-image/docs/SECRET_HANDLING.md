# Secret Handling

## Inputs

The bootstrap image accepts either:

```txt
/input/env.gpg
```

or:

```txt
/input/.env
```

If `.env` is provided, the image can create:

```txt
/output/env.gpg
```

## Encryption modes

### existing

Use this when `env.gpg` already exists.

```txt
DND_ENV_ENCRYPTION_MODE=existing
```

### symmetric

Use this for quick bootstrap where a passphrase is acceptable.

```txt
DND_ENV_ENCRYPTION_MODE=symmetric
ENV_GPG_PASSPHRASE=...
```

### recipient

Use this for stronger operator/recovery flow where a known GPG recipient public key is available.

```txt
DND_ENV_ENCRYPTION_MODE=recipient
ENV_GPG_RECIPIENT=operator@example.com
```

## Rules

Never commit:

- `.env`,
- `env.gpg`,
- GPG private keys,
- WireGuard private keys,
- Cloudflare tunnel tokens,
- Dockhand/Hawser tokens,
- GitHub deploy keys.

The image should log only paths and hashes, never secret values.
