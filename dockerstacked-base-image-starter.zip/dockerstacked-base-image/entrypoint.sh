#!/usr/bin/env bash
set -euo pipefail

cmd="${1:-help}"
shift || true

case "$cmd" in
  help|--help|-h)
    cat <<'USAGE'
DockerStacked init image

Commands:
  help             Show this help.
  preflight        Check Docker socket, inputs, and required settings.
  encrypt-env      Convert /input/.env to /output/env.gpg.
  init-controller  Prepare controller host paths and optionally run controller bootstrap.
  print-summary    Print resolved settings.

Typical flow:
  docker compose --env-file project.env -f docker-compose.init.yml run --rm dockerstacked-init preflight
  docker compose --env-file project.env -f docker-compose.init.yml run --rm dockerstacked-init encrypt-env
  docker compose --env-file project.env -f docker-compose.init.yml run --rm dockerstacked-init init-controller
USAGE
    ;;
  preflight)
    /usr/local/lib/dockerstacked/init-controller.sh preflight
    ;;
  encrypt-env)
    /usr/local/lib/dockerstacked/encrypt-env.sh
    ;;
  init-controller)
    /usr/local/lib/dockerstacked/init-controller.sh init
    ;;
  print-summary)
    /usr/local/lib/dockerstacked/init-controller.sh summary
    ;;
  *)
    echo "ERROR: unknown command: $cmd" >&2
    exit 2
    ;;
esac
