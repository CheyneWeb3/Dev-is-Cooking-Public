#!/usr/bin/env bash
set -euo pipefail

mode="${DND_ENV_ENCRYPTION_MODE:-existing}"
input_env="/input/.env"
input_gpg="/input/env.gpg"
out_gpg="/output/env.gpg"

mkdir -p /output

case "$mode" in
  existing)
    if [[ ! -f "$input_gpg" ]]; then
      echo "ERROR: DND_ENV_ENCRYPTION_MODE=existing but /input/env.gpg not found" >&2
      exit 1
    fi
    cp -f "$input_gpg" "$out_gpg"
    chmod 600 "$out_gpg"
    echo "OK: copied existing env.gpg to $out_gpg"
    ;;
  symmetric)
    if [[ ! -f "$input_env" ]]; then
      echo "ERROR: /input/.env not found" >&2
      exit 1
    fi
    if [[ -z "${ENV_GPG_PASSPHRASE:-}" ]]; then
      echo "ERROR: ENV_GPG_PASSPHRASE is required for symmetric encryption" >&2
      exit 1
    fi
    gpg --batch --yes --symmetric --cipher-algo AES256 \
      --passphrase "$ENV_GPG_PASSPHRASE" \
      --output "$out_gpg" "$input_env"
    chmod 600 "$out_gpg"
    echo "OK: encrypted /input/.env to $out_gpg using symmetric gpg"
    ;;
  recipient)
    if [[ ! -f "$input_env" ]]; then
      echo "ERROR: /input/.env not found" >&2
      exit 1
    fi
    if [[ -z "${ENV_GPG_RECIPIENT:-}" ]]; then
      echo "ERROR: ENV_GPG_RECIPIENT is required for recipient encryption" >&2
      exit 1
    fi
    gpg --batch --yes --encrypt --recipient "$ENV_GPG_RECIPIENT" \
      --output "$out_gpg" "$input_env"
    chmod 600 "$out_gpg"
    echo "OK: encrypted /input/.env to $out_gpg for recipient $ENV_GPG_RECIPIENT"
    ;;
  *)
    echo "ERROR: unknown DND_ENV_ENCRYPTION_MODE=$mode" >&2
    exit 2
    ;;
esac

sha256sum "$out_gpg" | tee /output/env.gpg.sha256
