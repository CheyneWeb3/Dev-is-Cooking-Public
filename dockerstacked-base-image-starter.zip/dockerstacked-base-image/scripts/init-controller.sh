#!/usr/bin/env bash
set -euo pipefail

mode="${1:-summary}"

PROJECT_NAME="${PROJECT_NAME:-dndeal}"
DND_REPO_URL="${DND_REPO_URL:-git@github.com:CheyneWeb3/DND-Cooking.git}"
DND_REPO_BRANCH="${DND_REPO_BRANCH:-DockerStacked}"
DND_REPO_DIR="${DND_REPO_DIR:-/workspace/repo}"
DND_HOST_APP_DIR="${DND_HOST_APP_DIR:-/opt/DND-Cooking-main}"
DND_HOST_UPLOAD_DIR="${DND_HOST_UPLOAD_DIR:-/home/cheynespc/upload}"
DND_BOOTSTRAP_EXECUTE="${DND_BOOTSTRAP_EXECUTE:-0}"

summary() {
  cat <<EOF2
DockerStacked bootstrap settings
PROJECT_NAME=$PROJECT_NAME
DND_REPO_URL=$DND_REPO_URL
DND_REPO_BRANCH=$DND_REPO_BRANCH
DND_REPO_DIR=$DND_REPO_DIR
DND_HOST_APP_DIR=$DND_HOST_APP_DIR
DND_HOST_UPLOAD_DIR=$DND_HOST_UPLOAD_DIR
DND_BOOTSTRAP_EXECUTE=$DND_BOOTSTRAP_EXECUTE
EOF2
}

preflight() {
  summary
  echo
  echo "=== Docker socket proof ==="
  docker version --format 'client={{.Client.Version}} server={{.Server.Version}}'

  echo
  echo "=== env input proof ==="
  if [[ -f /input/env.gpg ]]; then
    echo "found /input/env.gpg"
  elif [[ -f /output/env.gpg ]]; then
    echo "found /output/env.gpg"
  elif [[ -f /input/.env ]]; then
    echo "found /input/.env"
  else
    echo "WARN: no /input/env.gpg, /output/env.gpg, or /input/.env found"
  fi

  echo
  echo "=== target path proof ==="
  mkdir -p "$DND_HOST_APP_DIR" "$DND_HOST_UPLOAD_DIR" /controller-data
  test -w "$DND_HOST_APP_DIR" && echo "writable: $DND_HOST_APP_DIR" || echo "not writable: $DND_HOST_APP_DIR"
  test -w "$DND_HOST_UPLOAD_DIR" && echo "writable: $DND_HOST_UPLOAD_DIR" || echo "not writable: $DND_HOST_UPLOAD_DIR"
}

clone_repo() {
  if [[ -d "$DND_HOST_APP_DIR/.git" ]]; then
    echo "Repo already exists at $DND_HOST_APP_DIR; fetching branch"
    git -C "$DND_HOST_APP_DIR" fetch --all --prune
    git -C "$DND_HOST_APP_DIR" checkout "$DND_REPO_BRANCH"
    git -C "$DND_HOST_APP_DIR" pull --ff-only origin "$DND_REPO_BRANCH" || true
  else
    echo "Cloning $DND_REPO_URL#$DND_REPO_BRANCH to $DND_HOST_APP_DIR"
    rm -rf "$DND_HOST_APP_DIR"/* "$DND_HOST_APP_DIR"/.[!.]* "$DND_HOST_APP_DIR"/..?* 2>/dev/null || true
    git clone --branch "$DND_REPO_BRANCH" "$DND_REPO_URL" "$DND_HOST_APP_DIR"
  fi
}

install_env_gpg() {
  mkdir -p "$DND_HOST_UPLOAD_DIR"
  if [[ -f /output/env.gpg ]]; then
    cp -f /output/env.gpg "$DND_HOST_UPLOAD_DIR/env.gpg"
  elif [[ -f /input/env.gpg ]]; then
    cp -f /input/env.gpg "$DND_HOST_UPLOAD_DIR/env.gpg"
  else
    echo "ERROR: no env.gpg found. Run encrypt-env first or mount /input/env.gpg." >&2
    exit 1
  fi
  chmod 600 "$DND_HOST_UPLOAD_DIR/env.gpg"
  sha256sum "$DND_HOST_UPLOAD_DIR/env.gpg" | tee /output/installed-env.gpg.sha256
  echo "OK: installed env.gpg to $DND_HOST_UPLOAD_DIR/env.gpg"
}

write_summary_file() {
  mkdir -p /controller-data /output
  cat > /controller-data/dockerstacked-bootstrap-summary.txt <<EOF2
PROJECT_NAME=$PROJECT_NAME
DND_REPO_URL=$DND_REPO_URL
DND_REPO_BRANCH=$DND_REPO_BRANCH
DND_HOST_APP_DIR=$DND_HOST_APP_DIR
DND_HOST_UPLOAD_DIR=$DND_HOST_UPLOAD_DIR
BOOTSTRAPPED_AT=$(date -u +%Y-%m-%dT%H:%M:%SZ)
EOF2
  cp -f /controller-data/dockerstacked-bootstrap-summary.txt /output/bootstrap-summary.txt
}

run_controller_bootstrap() {
  if [[ "$DND_BOOTSTRAP_EXECUTE" != "1" ]]; then
    cat <<'EOF2'
DRY RUN ONLY: DND_BOOTSTRAP_EXECUTE is not 1.
The repo and env.gpg are staged. To run controller scripts for real, set:
  DND_BOOTSTRAP_EXECUTE=1
Then rerun init-controller.
EOF2
    return 0
  fi

  echo "=== ensure Docker tools ==="
  if [[ -x "$DND_HOST_APP_DIR/ops/host-tools/dnd-ensure-docker.sh" ]]; then
    bash "$DND_HOST_APP_DIR/ops/host-tools/dnd-ensure-docker.sh"
  fi

  echo "=== import env / start controller candidate ==="
  if [[ -x "$DND_HOST_APP_DIR/ops/docker-wg-lab/import-env-to-controller.sh" ]]; then
    ENV_GPG="$DND_HOST_UPLOAD_DIR/env.gpg" bash "$DND_HOST_APP_DIR/ops/docker-wg-lab/import-env-to-controller.sh" || true
  fi

  if [[ -x "$DND_HOST_APP_DIR/ops/docker-wg-lab/docker-wg-lab-up.sh" ]]; then
    bash "$DND_HOST_APP_DIR/ops/docker-wg-lab/docker-wg-lab-up.sh"
  else
    echo "WARN: controller start script not found: ops/docker-wg-lab/docker-wg-lab-up.sh"
  fi
}

case "$mode" in
  summary) summary ;;
  preflight) preflight ;;
  init)
    preflight
    clone_repo
    install_env_gpg
    write_summary_file
    run_controller_bootstrap
    ;;
  *)
    echo "ERROR: unknown init-controller mode: $mode" >&2
    exit 2
    ;;
esac
